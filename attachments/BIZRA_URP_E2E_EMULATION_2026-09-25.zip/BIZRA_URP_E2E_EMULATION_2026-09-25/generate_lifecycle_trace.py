#!/usr/bin/env python3
import hashlib,json
from pathlib import Path

def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def H(domain,x):
    h=hashlib.sha256(); h.update(f'BIZRA|{domain}|v1|'.encode()); h.update(canon(x)); return h.hexdigest()

def step(seq, stage, state, evidence, truth='DERIVED_EMULATION'):
    body={'seq':seq,'stage':stage,'state':state,'evidence':evidence,'truth_label':truth}
    body['step_hash']=H('LIFECYCLE_STEP',body)
    return body

def main(out):
    node0={'node_ordinal':0,'node_pseudonym':'node-00000000','pat_count':7,'local_private':True}
    node1={'node_ordinal':1,'node_pseudonym':'node-00000001','pat_count':7,'local_private':True}
    grant={'grant_id':'hg-1','human':'node0-sovereign','scope':['governed_mutation','resource_use'],'expires_after_missions':64}
    lease={'lease_id':'al-1','grant_hash':H('HUMAN_GRANT',grant),'effect_classes':['GOVERNED_MUTATION'],'max_actions':64,'network':'urp_only','direct_p2p':False}
    mission={'mission_id':'trace-mission-1','from':'node-00000000','effect':'GOVERNED_MUTATION','payload_hash':H('PAYLOAD',{'task':'transform verified artifact'}),'authority_lease_hash':H('AUTHORITY_LEASE',lease)}
    offer={'offer_id':'ro-1','owner':'node-00000001','resource_type':'compute','opt_in':True,'raw_private_data_shared':False}
    resource_lease={'resource_lease_id':'rl-1','offer_hash':H('RESOURCE_OFFER',offer),'mission_id':mission['mission_id'],'fencing_token':1}
    steps=[]; n=1
    def add(stage,state,evidence):
        nonlocal n; steps.append(step(n,stage,state,evidence)); n+=1
    add('NODE0_ACTIVATION','ACTIVE_LOCAL',{'node':node0,'sat_contribution_logical_identities':5})
    add('DEMA_INTENT','INTENT_CAPTURED',{'surface':'DEMA','raw_network_access':False})
    add('PAT_PLAN','MISSION_PROPOSED',{'pat_local':True,'mission_hash':H('MISSION',mission)})
    add('HUMAN_AUTHORITY','LEASE_ISSUED',{'grant_hash':H('HUMAN_GRANT',grant),'lease_hash':H('AUTHORITY_LEASE',lease)})
    add('MEMBRANE','ADMITTED',{'direct_p2p':False,'privacy':'MIN_DISCLOSURE','policy':'sim-policy-v3'})
    add('NODE1_REGISTRY','SECOND_HUMAN_BOUND',{'node':node1,'mutual_relationship':'bounded'})
    add('RESOURCE_OFFER','OPT_IN_ADVERTISED',{'offer_hash':H('RESOURCE_OFFER',offer)})
    add('SCHEDULER','RESOURCE_LEASED',{'lease_hash':H('RESOURCE_LEASE',resource_lease),'fencing_token':1})
    add('WORKER_FAILURE','DETECTED',{'worker':'ephemeral-sat-worker-A','effect_committed':False})
    stale={'resource_lease_id':'rl-1','fencing_token':1,'attempt':'late_write'}
    resource_lease2=dict(resource_lease); resource_lease2['fencing_token']=2
    add('RECOVERY','REFENCED',{'stale_attempt_hash':H('STALE_ATTEMPT',stale),'stale_token_rejected':True,'new_fencing_token':2})
    votes=[
      {'role':'Validator','verdict':'PERMIT'},
      {'role':'Oracle','verdict':'PERMIT'},
      {'role':'Mediator','verdict':'PERMIT'},
      {'role':'Archivist','verdict':'PERMIT'},
      {'role':'Sentinel','verdict':'ABSTAIN'}]
    add('SAT_COMMITTEE','4_OF_5_PERMIT',{'roles':[v['role'] for v in votes],'votes':votes,'independent_lineages':True})
    execution={'mission_id':mission['mission_id'],'resource_lease_hash':H('RESOURCE_LEASE',resource_lease2),'result_hash':H('RESULT',{'status':'ok','artifact':'verified-transform'}),'effect':'bounded'}
    add('EXECUTION','COMPLETED',execution)
    receipt_payload={'mission_id':mission['mission_id'],'issuer':'node-00000000','result_hash':execution['result_hash'],'policy_hash':'sim-policy-v3','canon_hash':'sim-canon-v3','prev_receipt_hash':'GENESIS','sequence':1,'fencing_token':2,'private_payload_included':False}
    receipt_hash=H('EXECUTION_RECEIPT',receipt_payload)
    add('RECEIPT','SIGNED_STATEMENT_CREATED',{'receipt_hash':receipt_hash,'issuer_signature_kind':'simulated'})
    inclusion={'receipt_hash':receipt_hash,'shard':'shard-0','sequence':1,'leaf_hash':H('TRANSPARENCY_LEAF',{'receipt_hash':receipt_hash})}
    add('TRANSPARENCY','INCLUSION_PROOF_ISSUED',inclusion)
    checkpoint={'previous_checkpoint_hash':'GENESIS','shard_roots':[inclusion['leaf_hash']],'policy_hash':'sim-policy-v3','canon_hash':'sim-canon-v3'}
    checkpoint_hash=H('EPOCH_CHECKPOINT',checkpoint)
    add('CHECKPOINT','SEALED',{'checkpoint_hash':checkpoint_hash})
    block={'parent':'BLOCK0','receipt_hash':receipt_hash,'checkpoint_hash':checkpoint_hash}
    block_hash=H('BLOCKTREE',block)
    add('BLOCKTREE','LINEAGE_APPENDED',{'parent':'BLOCK0','block_hash':block_hash,'single_parent':True})
    links=[
      {'type':'verification','from':receipt_hash,'to':block_hash},
      {'type':'dependency','from':mission['mission_id'],'to':offer['offer_id']}]
    add('BLOCKGRAPH','TYPED_LINKS_ADDED',{'links':links,'lineage_overloaded':False})
    wisdom={'wisdom_id':'w-1','source_receipt_hash':receipt_hash,'states':['OBSERVED','CANDIDATE','CHALLENGED','SUPPORTED','ADMITTED','ACTIVE'],'raw_private_data':False,'operator_share_consent':True}
    add('UKE','WISDOM_ACTIVE',{'wisdom_hash':H('WISDOM_OBJECT',wisdom),'states':wisdom['states']})
    impact={'impact_id':'i-1','source_receipt_hash':receipt_hash,'independent_attestations':2,'mode':'SHADOW','settlement_power':0}
    add('POI','SHADOW_EVALUATED',{'impact_hash':H('IMPACT_RECORD',impact),'settlement_power':0})
    add('RESOURCE_RELEASE','LEASE_RELEASED',{'resource_lease_id':'rl-1','fencing_token':2})
    add('RELATIONSHIP_REVOCATION','NODE1_DISCONNECTED',{'node0_local_state_preserved':True,'node1_local_state_preserved':True,'shared_authority_revoked':True})
    invariants={
      'pat_local':True,'sat_shared_side':True,'no_direct_node_control':True,'authority_before_effect':True,
      'stale_fence_rejected':True,'receipt_registered':True,'checkpoint_batched':True,'blocktree_single_parent':True,
      'blockgraph_typed':True,'wisdom_requires_consent':True,'poi_settlement_power_zero':True,'local_state_survives_disconnect':True}
    add('FINAL_INVARIANTS','PASS',invariants)
    trace={'schema':'bizra.urp.lifecycle_trace.v1','truth_label':'DERIVED_EMULATION_NOT_RUNTIME_RECEIPT','scenario':'two-human cross-node governed mission with worker-failure recovery','steps':steps,'final_invariants':invariants}
    trace['trace_hash']=H('LIFECYCLE_TRACE',trace)
    Path(out).write_text(json.dumps(trace,indent=2,sort_keys=True))
    print(json.dumps({'steps':len(steps),'trace_hash':trace['trace_hash'],'all_invariants':all(invariants.values())},indent=2))

if __name__=='__main__':
    import sys
    main(sys.argv[1])
