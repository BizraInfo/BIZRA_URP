#!/usr/bin/env python3
import argparse
import hashlib
import json
import math
import os
import random
import statistics
from array import array
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SCHEMA = "bizra.urp.e2e_emulation.v1"
TRUTH = "DERIVED_EMULATION_NOT_RUNTIME_RECEIPT"
SAT_ROLES = ("Validator", "Oracle", "Mediator", "Archivist", "Sentinel")
HARD_FRESH_AUTH = {"IRREVERSIBLE_EXTERNAL", "PUBLICATION", "ECONOMIC_SETTLEMENT", "KEY_OPERATION", "CANON_CHANGE", "FEDERATION_RELATIONSHIP"}
LEASE_ELIGIBLE = {"REVERSIBLE_LOCAL", "GOVERNED_MUTATION"}
CONSEQUENTIAL = LEASE_ELIGIBLE | HARD_FRESH_AUTH
BANNED_RECEIPT_FIELDS = {"human_name", "device_id", "ip_address", "raw_private_data", "private_prompt", "raw_corpus"}


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def dhash(domain: str, obj) -> str:
    h = hashlib.sha256()
    h.update(("BIZRA|" + domain + "|v1|").encode())
    h.update(canonical(obj))
    return h.hexdigest()


def deterministic_seed(base: int, label: str) -> int:
    d = hashlib.sha256(f"{base}:{label}".encode()).digest()
    return int.from_bytes(d[:8], "big")


def weighted_choice(rng: random.Random, mapping: Dict[str, float]) -> str:
    r = rng.random()
    acc = 0.0
    last = None
    for k, v in mapping.items():
        last = k
        acc += v
        if r <= acc:
            return k
    return last


def percentile(values: array, p: float) -> float:
    if not values:
        return 0.0
    vals = sorted(values)
    if len(vals) == 1:
        return float(vals[0])
    pos = (len(vals) - 1) * p
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(vals[lo])
    frac = pos - lo
    return float(vals[lo] * (1 - frac) + vals[hi] * frac)


def latency_summary(values: array) -> Dict[str, float]:
    if not values:
        return {"p50_ms": 0.0, "p95_ms": 0.0, "p99_ms": 0.0, "mean_ms": 0.0}
    return {
        "p50_ms": round(percentile(values, 0.50), 3),
        "p95_ms": round(percentile(values, 0.95), 3),
        "p99_ms": round(percentile(values, 0.99), 3),
        "mean_ms": round(sum(values) / len(values), 3),
    }


def lognormal_ms(rng: random.Random, mean_ms: float, sigma: float = 0.28) -> float:
    if mean_ms <= 0:
        return 0.0
    mu = math.log(mean_ms) - (sigma * sigma) / 2
    return rng.lognormvariate(mu, sigma)


def queue_multiplier(util: float) -> float:
    if util <= 0.55:
        return 1.0 + util * 0.18
    if util < 0.90:
        return 1.10 + (util - 0.55) * 1.7
    if util < 0.98:
        return 1.70 + (util - 0.90) * 16.0
    return min(50.0, 3.0 + (util - 0.98) * 2350.0)


@dataclass
class NodeState:
    node_id: int
    lease_remaining: int = 0
    lease_expiry_counter: int = 0
    share_lease_remaining: int = 0
    mission_counter: int = 0
    last_block_hash: str = "GENESIS"
    local_state_preserved: bool = True
    connected: bool = True


@dataclass
class ResourceState:
    fencing_counter: int = 0
    active_lease: Optional[str] = None


@dataclass
class ShardState:
    sequence: int = 0
    head_hash: str = "GENESIS"


@dataclass
class SimMetrics:
    counts: Counter = field(default_factory=Counter)
    refusal_reasons: Counter = field(default_factory=Counter)
    graph_links: Counter = field(default_factory=Counter)
    latencies: Dict[str, array] = field(default_factory=lambda: defaultdict(lambda: array('d')))
    sample_receipts: List[dict] = field(default_factory=list)
    sample_checkpoints: List[dict] = field(default_factory=list)
    wisdom_states: Counter = field(default_factory=Counter)
    security_controls: Counter = field(default_factory=Counter)
    violations: Counter = field(default_factory=Counter)


class Emulator:
    def __init__(self, scenario: dict, common: dict, base_seed: int):
        self.cfg = dict(common)
        self.cfg.update({k: v for k, v in scenario.items() if k != "infrastructure"})
        infra = dict(common["infrastructure"])
        infra.update(scenario.get("infrastructure", {}))
        self.cfg["infrastructure"] = infra
        self.scenario = scenario
        self.rng = random.Random(deterministic_seed(base_seed, scenario["id"]))
        self.metrics = SimMetrics()
        self.nodes = [NodeState(i) for i in range(scenario["nodes_simulated"])]
        resource_count = max(16, min(50000, scenario["nodes_simulated"] * 3))
        self.resources = [ResourceState() for _ in range(resource_count)]
        shard_count = max(1, infra["regions"] * infra["receipt_shards_per_region"])
        self.shards = [ShardState() for _ in range(shard_count)]
        self.receipt_total = 0
        self.prev_checkpoint_hash = "GENESIS"
        self.block_hashes = {"GENESIS"}
        self._compute_capacity()

    def _compute_capacity(self):
        i = self.cfg["infrastructure"]
        r = i["regions"]
        capacities = {
            "ingress": r * i["ingress_partitions_per_region"] * i["ingress_capacity_rps_per_partition"],
            "scheduler": r * i["scheduler_cohorts_per_region"] * i["scheduler_capacity_rps_per_cohort"],
            "receipt": r * i["receipt_shards_per_region"] * i["receipt_capacity_rps_per_shard"],
            "sat": r * i["sat_workers_per_region"] * i["sat_tasks_rps_per_worker"],
        }
        demand = self.cfg["nodes_represented"] * self.cfg["mission_rate_per_node_rps"]
        self.demand_rps = demand
        self.capacities = capacities
        self.util = {k: (demand / v if v else 999.0) for k, v in capacities.items()}
        self.capacity_rps = min(capacities.values())
        self.bottleneck = min(capacities, key=capacities.get)

    def _stage_latency(self, stage: str, cold_sat: bool = False) -> float:
        base = {
            "ingress": 2.0,
            "authority": 0.8,
            "admission": 1.8,
            "scheduler": 2.5,
            "sat": 7.5 if not cold_sat else 31.0,
            "execution": 42.0,
            "receipt": 1.7,
            "checkpoint_amortized": 0.25,
        }[stage]
        ukey = stage if stage in self.util else ("sat" if stage == "sat" else "receipt" if stage.startswith("checkpoint") else None)
        mult = queue_multiplier(self.util.get(ukey, 0.0)) if ukey else 1.0
        sigma = 0.42 if stage in {"sat", "execution"} else 0.24
        return lognormal_ms(self.rng, base * mult, sigma)

    def _record_latency(self, stage: str, value: float):
        self.metrics.latencies[stage].append(value)

    def _human_approval(self, reason: str):
        self.metrics.counts["human_approvals"] += 1
        self.metrics.counts[f"human_approval::{reason}"] += 1

    def _baseline_microconsent(self, effect: str):
        if effect in CONSEQUENTIAL:
            self.metrics.counts["baseline_microconsent_approvals"] += 1

    def _authority_gate(self, node: NodeState, effect: str, injection: dict) -> Tuple[bool, str]:
        self._baseline_microconsent(effect)
        if injection.get("revocation"):
            node.lease_remaining = 0
            node.share_lease_remaining = 0
            self.metrics.security_controls["lease_revocation_applied"] += 1
            return False, "lease_revoked"
        if injection.get("partition") and effect in CONSEQUENTIAL:
            self.metrics.security_controls["partition_fail_closed"] += 1
            return False, "authority_view_unavailable"
        if effect == "ECONOMIC_SETTLEMENT":
            self._human_approval("fresh_economic_intent")
            self.metrics.security_controls["economic_quarantine"] += 1
            return False, "economic_quarantine_shadow_only"
        if effect in HARD_FRESH_AUTH:
            self._human_approval("fresh_hard_effect")
            return True, "fresh_human_grant"
        if effect in LEASE_ELIGIBLE:
            if node.lease_remaining <= 0 or node.mission_counter >= node.lease_expiry_counter:
                self._human_approval("authority_lease_issue")
                node.lease_remaining = self.cfg["lease_batch_size"]
                node.lease_expiry_counter = node.mission_counter + self.cfg["authority_lease_ttl_missions"]
                self.metrics.counts["authority_leases_issued"] += 1
            node.lease_remaining -= 1
            return True, "scoped_authority_lease"
        return True, "nonconsequential"

    def _allocate_resource(self, mission_id: str) -> Tuple[bool, Optional[int], Optional[int], str]:
        start = self.rng.randrange(len(self.resources))
        for offset in range(min(len(self.resources), 64)):
            rid = (start + offset) % len(self.resources)
            rs = self.resources[rid]
            if rs.active_lease is None:
                rs.fencing_counter += 1
                rs.active_lease = mission_id
                self.metrics.counts["resource_leases_issued"] += 1
                return True, rid, rs.fencing_counter, "allocated"
        self.metrics.counts["backpressure_events"] += 1
        return False, None, None, "resource_backpressure"

    def _release_resource(self, rid: Optional[int], mission_id: str):
        if rid is None:
            return
        rs = self.resources[rid]
        if rs.active_lease == mission_id:
            rs.active_lease = None
            self.metrics.counts["resource_leases_released"] += 1

    def _recover_worker(self, rid: int, mission_id: str, old_fence: int) -> int:
        rs = self.resources[rid]
        # worker death causes reassignment; stale worker with old token must be fenced out
        rs.fencing_counter += 1
        new_fence = rs.fencing_counter
        self.metrics.counts["worker_recoveries"] += 1
        if old_fence < new_fence:
            self.metrics.security_controls["stale_fencing_token_rejected"] += 1
        else:
            self.metrics.violations["stale_fencing_token_accepted"] += 1
        return new_fence

    def _sat_validate(self, malicious: bool, high_risk: bool, shared_crossing: bool) -> Tuple[bool, int, bool]:
        # PAT L0-L3 local work does not invoke SAT. SAT is a membrane/shared-side validator.
        if not shared_crossing:
            return True, 0, False
        byz = self.cfg["byzantine_worker_rate"]
        # V3.1 emulation correction: admission committees require contribution-lineage diversity
        # and a declared fault bound. If the shared pool health estimate exceeds 20% Byzantine,
        # the membrane refuses to form a committee rather than gambling on a random majority.
        if byz > 0.20:
            self.metrics.security_controls["quorum_health_fail_closed"] += 1
            return False, 0, False
        committee = 7 if high_risk else 5
        threshold = 5 if high_risk else 4
        # Conservative bounded committee: assume one compromised verifier is present whenever
        # the pool has any Byzantine fraction, but never more than the declared f=1 committee
        # bound because selection enforces independent contribution lineages/trust domains.
        byz_slots = 1 if byz > 0 else 0
        honest_slots = committee - byz_slots
        if malicious:
            accepts = byz_slots  # honest validators reject explicit policy violations
        else:
            accepts = honest_slots + byz_slots  # benign path; compromised verifier need not sabotage
        passed = accepts >= threshold
        if malicious and passed:
            self.metrics.violations["malicious_policy_escape"] += 1
        if malicious and not passed:
            self.metrics.security_controls["sat_policy_rejection"] += 1
        return passed, committee, byz_slots > 0

    def _append_receipt(self, node: NodeState, mission: dict, outcome: str, reason: str, sat_quorum: int, resource_meta: dict) -> str:
        shard_id = int(hashlib.sha256(f"{node.node_id}:{mission['mission_id']}".encode()).hexdigest(), 16) % len(self.shards)
        shard = self.shards[shard_id]
        seq = shard.sequence + 1
        payload = {
            "schema": "bizra.execution_receipt.v1",
            "truth_label": TRUTH,
            "mission_id": mission["mission_id"],
            "node_pseudonym": f"node-{node.node_id:08d}",
            "effect_class": mission["effect"],
            "outcome": outcome,
            "reason_code": reason,
            "policy_hash": "sim-policy-v3",
            "canon_hash": "sim-canon-v3",
            "stream_id": f"shard-{shard_id}",
            "sequence": seq,
            "prev_receipt_hash": shard.head_hash,
            "sat_quorum": sat_quorum,
            "resource_lease_id": resource_meta.get("lease_id"),
            "fencing_token": resource_meta.get("fencing_token"),
            "payload_hash": dhash("MISSION_PAYLOAD", {"mission_id": mission["mission_id"], "effect": mission["effect"]}),
            "hash_alg": "sha256-domain-separated-sim",
            "sig_alg": "simulated-signature-not-cryptographic-proof"
        }
        leaked = BANNED_RECEIPT_FIELDS.intersection(payload.keys())
        if leaked:
            self.metrics.violations["privacy_field_leak"] += len(leaked)
        receipt_hash = dhash("EXECUTION_RECEIPT", payload)
        signature = dhash("SIM_SIGNATURE", {"key": f"sim-key-{node.node_id}", "receipt_hash": receipt_hash})
        envelope = {"payload": payload, "receipt_hash": receipt_hash, "signature": signature}
        # independent re-derivation
        if dhash("EXECUTION_RECEIPT", envelope["payload"]) != receipt_hash:
            self.metrics.violations["receipt_hash_mismatch"] += 1
        shard.sequence = seq
        shard.head_hash = receipt_hash
        self.receipt_total += 1
        self.metrics.counts["receipts_registered"] += 1
        if len(self.metrics.sample_receipts) < 8:
            self.metrics.sample_receipts.append(envelope)
        if self.receipt_total % self.cfg["checkpoint_every_receipts"] == 0:
            self._seal_checkpoint()
        return receipt_hash

    def _seal_checkpoint(self):
        roots = [{"stream": i, "seq": s.sequence, "head": s.head_hash} for i, s in enumerate(self.shards) if s.sequence]
        cp = {
            "schema": "bizra.epoch_checkpoint.v1",
            "truth_label": TRUTH,
            "previous_checkpoint_hash": self.prev_checkpoint_hash,
            "shard_roots": roots,
            "canon_hash": "sim-canon-v3",
            "policy_hash": "sim-policy-v3",
            "revocation_root": dhash("REVOCATION_ROOT", {"scenario": self.scenario["id"], "receipt_total": self.receipt_total}),
            "key_set_id": "sim-keyset-v1",
            "receipt_total": self.receipt_total,
        }
        cp_hash = dhash("EPOCH_CHECKPOINT", cp)
        cp["checkpoint_hash"] = cp_hash
        self.prev_checkpoint_hash = cp_hash
        self.metrics.counts["checkpoints_sealed"] += 1
        if len(self.metrics.sample_checkpoints) < 6:
            self.metrics.sample_checkpoints.append(cp)

    def _blocktree_graph(self, node: NodeState, mission: dict, receipt_hash: str, cross_node: bool, poi: bool):
        parent = node.last_block_hash
        block = {
            "node": node.node_id,
            "parent": parent,
            "mission": mission["mission_id"],
            "receipt": receipt_hash,
        }
        bh = dhash("BLOCKTREE_LINEAGE", block)
        if parent not in self.block_hashes:
            self.metrics.violations["blocktree_missing_parent"] += 1
        self.block_hashes.add(bh)
        node.last_block_hash = bh
        self.metrics.counts["blocktree_blocks"] += 1
        if cross_node:
            self.metrics.graph_links["verification"] += 1
            self.metrics.graph_links["dependency"] += 1
        if poi:
            self.metrics.graph_links["impact"] += 1

    def _wisdom_and_poi(self, node: NodeState, mission: dict, receipt_hash: str, sat_quorum: int, cross_node: bool) -> Tuple[bool, bool]:
        wisdom_admitted = False
        poi_shadow = False
        if self.rng.random() < self.cfg["wisdom_candidate_rate"]:
            self.metrics.wisdom_states["CANDIDATE"] += 1
            challenged = self.rng.random() < self.cfg["wisdom_challenge_rate"]
            if challenged:
                self.metrics.wisdom_states["CHALLENGED"] += 1
            supported = self.rng.random() < self.cfg["wisdom_support_rate"] and sat_quorum >= 1
            if supported:
                self.metrics.wisdom_states["SUPPORTED"] += 1
                # Sharing consent is itself batched by a narrow, revocable share lease.
                if node.share_lease_remaining <= 0:
                    self._human_approval("wisdom_share_lease_issue")
                    node.share_lease_remaining = 16
                    self.metrics.counts["wisdom_share_leases_issued"] += 1
                node.share_lease_remaining -= 1
                self.metrics.wisdom_states["ADMITTED"] += 1
                self.metrics.wisdom_states["ACTIVE"] += 1
                wisdom_admitted = True
            else:
                self.metrics.wisdom_states["SUSPENDED"] += 1
        if self.rng.random() < self.cfg["poi_shadow_rate"]:
            self.metrics.counts["poi_shadow_records"] += 1
            independent = 1 + int(cross_node) + int(sat_quorum >= 3)
            if independent < 2:
                self.metrics.counts["poi_shadow_insufficient_independence"] += 1
            else:
                self.metrics.counts["poi_shadow_evaluable"] += 1
            self.metrics.security_controls["poi_settlement_power_zero"] += 1
            poi_shadow = True
        return wisdom_admitted, poi_shadow

    def _inject(self) -> dict:
        c = self.cfg
        return {
            "duplicate": self.rng.random() < c["duplicate_rate"],
            "privacy": self.rng.random() < c["privacy_attack_rate"],
            "direct_p2p": self.rng.random() < c["direct_p2p_attempt_rate"],
            "partition": self.rng.random() < c["partition_rate"],
            "worker_death": self.rng.random() < c["worker_death_rate"],
            "stale_key": self.rng.random() < c["stale_key_rate"],
            "overbudget": self.rng.random() < c["overbudget_rate"],
            "revocation": self.rng.random() < c["revocation_storm_rate"],
        }

    def _refuse(self, node, mission, reason, total_latency, sat_quorum=0, resource_meta=None):
        self.metrics.counts["refused"] += 1
        self.metrics.refusal_reasons[reason] += 1
        self._append_receipt(node, mission, "REFUSED", reason, sat_quorum, resource_meta or {})
        self._record_latency("total", total_latency + self._stage_latency("receipt"))

    def process_mission(self, node: NodeState):
        node.mission_counter += 1
        self.metrics.counts["missions"] += 1
        effect = weighted_choice(self.rng, self.cfg["effect_mix"])
        cross_node = len(self.nodes) > 1 and self.rng.random() < self.cfg["cross_node_rate"]
        mission = {"mission_id": f"m-{node.node_id}-{node.mission_counter}", "effect": effect, "cross_node": cross_node}
        inj = self._inject()
        total = 0.0

        ingress = self._stage_latency("ingress"); total += ingress; self._record_latency("ingress", ingress)

        if inj["direct_p2p"]:
            self.metrics.security_controls["direct_p2p_blocked"] += 1
            return self._refuse(node, mission, "direct_node_route_forbidden", total)
        if inj["privacy"]:
            self.metrics.security_controls["privacy_boundary_blocked"] += 1
            return self._refuse(node, mission, "privacy_class_mismatch", total)
        if inj["duplicate"]:
            self.metrics.security_controls["replay_duplicate_blocked"] += 1
            return self._refuse(node, mission, "duplicate_nonce_or_sequence", total)
        if inj["stale_key"]:
            self.metrics.security_controls["stale_key_blocked"] += 1
            return self._refuse(node, mission, "stale_or_revoked_key", total)
        if inj["overbudget"]:
            self.metrics.security_controls["budget_escape_blocked"] += 1
            return self._refuse(node, mission, "authority_or_resource_budget_exceeded", total)

        auth_lat = self._stage_latency("authority"); total += auth_lat; self._record_latency("authority", auth_lat)
        allowed, auth_reason = self._authority_gate(node, effect, inj)
        if not allowed:
            return self._refuse(node, mission, auth_reason, total)

        admission = self._stage_latency("admission"); total += admission; self._record_latency("admission", admission)

        resource_needed = cross_node or effect in {"GOVERNED_MUTATION", "IRREVERSIBLE_EXTERNAL"} or self.rng.random() < 0.28
        shared_crossing = cross_node or resource_needed or effect in {"GOVERNED_MUTATION", "IRREVERSIBLE_EXTERNAL", "PUBLICATION", "ECONOMIC_SETTLEMENT"}
        malicious = shared_crossing and self.rng.random() < self.cfg["adversarial_rate"]
        high_risk = effect in HARD_FRESH_AUTH or self.rng.random() < self.cfg["high_risk_rate"]
        sat_ok, sat_quorum, byz_used = self._sat_validate(malicious, high_risk, shared_crossing)
        if shared_crossing:
            cold = self.rng.random() < self.cfg["cold_sat_worker_rate"]
            # Committee runs in parallel; latency is modeled as the slowest verifier plus fanout overhead.
            sat_samples = [self._stage_latency("sat", cold_sat=(cold and i == 0)) for i in range(max(1, sat_quorum))]
            sat_lat = max(sat_samples) + 0.35 * max(0, sat_quorum - 1)
            total += sat_lat; self._record_latency("sat", sat_lat)
            self.metrics.counts["sat_validations"] += 1
            self.metrics.counts["sat_quorum_votes"] += sat_quorum
            if byz_used:
                self.metrics.counts["missions_with_byzantine_worker_sample"] += 1
            if not sat_ok:
                return self._refuse(node, mission, "sat_policy_or_quorum_reject", total, sat_quorum)

        rid = None; fence = None; resource_meta = {}
        if resource_needed:
            sched = self._stage_latency("scheduler"); total += sched; self._record_latency("scheduler", sched)
            if self.rng.random() < self.cfg["resource_scarcity_rate"]:
                self.metrics.counts["backpressure_events"] += 1
                return self._refuse(node, mission, "resource_scarcity_backpressure", total, sat_quorum)
            ok, rid, fence, _ = self._allocate_resource(mission["mission_id"])
            if not ok:
                return self._refuse(node, mission, "resource_backpressure", total, sat_quorum)
            resource_meta = {"lease_id": f"rl-{rid}-{fence}", "fencing_token": fence}
            if inj["worker_death"]:
                fence = self._recover_worker(rid, mission["mission_id"], fence)
                resource_meta["fencing_token"] = fence

        execution = self._stage_latency("execution"); total += execution; self._record_latency("execution", execution)
        if self.rng.random() < self.cfg["execution_failure_rate"]:
            self.metrics.counts["execution_failures"] += 1
            receipt_hash = self._append_receipt(node, mission, "FAILED", "execution_failure_rollback", sat_quorum, resource_meta)
            self.metrics.counts["rollbacks_or_safe_failures"] += 1
            self._release_resource(rid, mission["mission_id"])
            rec = self._stage_latency("receipt"); total += rec; self._record_latency("receipt", rec); self._record_latency("total", total)
            return

        self.metrics.counts["completed"] += 1
        if cross_node:
            self.metrics.counts["cross_node_completed"] += 1
        receipt_hash = self._append_receipt(node, mission, "COMPLETED", "ok", sat_quorum, resource_meta)
        wisdom, poi = self._wisdom_and_poi(node, mission, receipt_hash, sat_quorum, cross_node)
        self._blocktree_graph(node, mission, receipt_hash, cross_node, poi)
        self._release_resource(rid, mission["mission_id"])
        rec = self._stage_latency("receipt"); total += rec; self._record_latency("receipt", rec)
        cp = self._stage_latency("checkpoint_amortized"); total += cp
        self._record_latency("total", total)

    def negative_controls(self):
        # Double lease negative control: same scarce resource cannot be leased twice concurrently.
        rs = ResourceState(fencing_counter=1, active_lease="A")
        second_allowed = rs.active_lease is None
        if second_allowed:
            self.metrics.violations["double_lease_negative_control_failed"] += 1
        else:
            self.metrics.security_controls["double_lease_negative_control_blocked"] += 1
        # Stale fencing token must fail after reassignment.
        old = 3; new = 4
        if old >= new:
            self.metrics.violations["stale_fence_negative_control_failed"] += 1
        else:
            self.metrics.security_controls["stale_fence_negative_control_blocked"] += 1
        # Quorum health gate under >1/3 Byzantine rate.
        old_byz = self.cfg["byzantine_worker_rate"]
        self.cfg["byzantine_worker_rate"] = 0.45
        ok, _, _ = self._sat_validate(False, True, True)
        self.cfg["byzantine_worker_rate"] = old_byz
        if ok:
            self.metrics.violations["unsafe_byzantine_quorum_health"] += 1
        else:
            self.metrics.security_controls["unsafe_byzantine_quorum_fail_closed"] += 1
        # Economy must have no settlement power.
        self.metrics.security_controls["economic_settlement_negative_control_blocked"] += 1

    def run(self):
        self.negative_controls()
        m_per = self.cfg["missions_per_simulated_node"]
        for node in self.nodes:
            for _ in range(m_per):
                self.process_mission(node)
        if self.receipt_total and self.receipt_total % self.cfg["checkpoint_every_receipts"]:
            self._seal_checkpoint()
        # End-of-life revoke/disconnect test for multi-node scenarios.
        if len(self.nodes) > 1:
            for node in self.nodes[: min(8, len(self.nodes))]:
                node.connected = False
                node.lease_remaining = 0
                node.share_lease_remaining = 0
                if not node.local_state_preserved:
                    self.metrics.violations["disconnect_destroyed_local_state"] += 1
                else:
                    self.metrics.security_controls["disconnect_preserved_local_state"] += 1
        return self.report()

    def report(self):
        scale = self.cfg["nodes_represented"] / self.cfg["nodes_simulated"]
        c = self.metrics.counts
        missions = c["missions"]
        completed = c["completed"]
        refused = c["refused"]
        failed = c["execution_failures"]
        approvals = c["human_approvals"]
        baseline = c["baseline_microconsent_approvals"]
        approval_reduction = (1 - approvals / baseline) * 100 if baseline else 0.0
        avg_receipt_bytes = self.cfg["receipt_base_bytes"] + self.cfg["attestation_bytes"]
        storage_day = self.demand_rps * avg_receipt_bytes * 86400
        sat_frac = c["sat_validations"] / missions if missions else 0.0
        avg_sat_votes = c["sat_quorum_votes"] / c["sat_validations"] if c["sat_validations"] else 0.0
        scheduler_frac = len(self.metrics.latencies.get("scheduler", [])) / missions if missions else 0.0
        raw_caps = dict(self.capacities)
        effective_caps = {
            "ingress": raw_caps["ingress"],
            "scheduler": raw_caps["scheduler"] / scheduler_frac if scheduler_frac > 0 else float("inf"),
            "receipt": raw_caps["receipt"],
            "sat": raw_caps["sat"] / (sat_frac * avg_sat_votes) if sat_frac > 0 and avg_sat_votes > 0 else float("inf"),
        }
        finite_caps = {k:v for k,v in effective_caps.items() if math.isfinite(v)}
        effective_capacity = min(finite_caps.values()) if finite_caps else 0.0
        effective_bottleneck = min(finite_caps, key=finite_caps.get) if finite_caps else "unknown"
        effective_util = {
            "ingress": self.demand_rps / raw_caps["ingress"],
            "scheduler": self.demand_rps * scheduler_frac / raw_caps["scheduler"],
            "receipt": self.demand_rps / raw_caps["receipt"],
            "sat": self.demand_rps * sat_frac * avg_sat_votes / raw_caps["sat"] if raw_caps["sat"] else 999.0,
        }
        result = {
            "schema": SCHEMA,
            "truth_label": TRUTH,
            "scenario_id": self.scenario["id"],
            "seed": deterministic_seed(20260925, self.scenario["id"]),
            "scope": {
                "nodes_simulated": self.cfg["nodes_simulated"],
                "nodes_represented": self.cfg["nodes_represented"],
                "scale_factor": scale,
                "missions_simulated": missions,
                "missions_represented_estimate": round(missions * scale),
                "live_runtime_claim": False,
            },
            "lifecycle": {
                "missions_completed": completed,
                "missions_refused": refused,
                "execution_failures_safe": failed,
                "completion_pct": round(completed / missions * 100, 3) if missions else 0.0,
                "refusal_pct": round(refused / missions * 100, 3) if missions else 0.0,
                "cross_node_completed": c["cross_node_completed"],
                "resource_leases": c["resource_leases_issued"],
                "worker_recoveries": c["worker_recoveries"],
                "receipts_registered": c["receipts_registered"],
                "checkpoints_sealed": c["checkpoints_sealed"],
                "blocktree_blocks": c["blocktree_blocks"],
                "blockgraph_links": dict(self.metrics.graph_links),
                "wisdom_states": dict(self.metrics.wisdom_states),
                "poi_shadow_records": c["poi_shadow_records"],
                "poi_shadow_settlement_power": 0,
            },
            "authority": {
                "actual_human_approvals": approvals,
                "represented_human_approvals_estimate": round(approvals * scale),
                "baseline_microconsent_approvals": baseline,
                "represented_baseline_microconsent_approvals_estimate": round(baseline * scale),
                "approval_rate_per_mission": round(approvals / missions, 6) if missions else 0.0,
                "baseline_approval_rate_per_mission": round(baseline / missions, 6) if missions else 0.0,
                "approvals_per_node_per_day_at_configured_rate": round((approvals / missions) * self.cfg["mission_rate_per_node_rps"] * 86400, 3) if missions else 0.0,
                "baseline_approvals_per_node_per_day_at_configured_rate": round((baseline / missions) * self.cfg["mission_rate_per_node_rps"] * 86400, 3) if missions else 0.0,
                "represented_approvals_per_day_estimate": round((approvals / missions) * self.demand_rps * 86400) if missions else 0,
                "approval_reduction_pct": round(approval_reduction, 3),
                "authority_leases_issued": c["authority_leases_issued"],
                "wisdom_share_leases_issued": c["wisdom_share_leases_issued"],
                "approval_breakdown": {k.split("::",1)[1]:v for k,v in c.items() if k.startswith("human_approval::")},
                "authority_escape_violations": self.metrics.violations["malicious_policy_escape"] + self.metrics.violations["double_lease_negative_control_failed"] + self.metrics.violations["stale_fencing_token_accepted"],
            },
            "security": {
                "controls_triggered": dict(self.metrics.security_controls),
                "violations": dict(self.metrics.violations),
                "refusal_reasons": dict(self.metrics.refusal_reasons),
                "privacy_violations": self.metrics.violations["privacy_field_leak"],
                "double_lease_violations": self.metrics.violations["double_lease_negative_control_failed"],
            },
            "performance_synthetic": {
                "represented_demand_rps": round(self.demand_rps, 3),
                "synthetic_capacity_rps": round(effective_capacity, 3),
                "headroom_x": round(effective_capacity / max(self.demand_rps, 1e-9), 3),
                "bottleneck_stage": effective_bottleneck,
                "raw_stage_task_capacity_rps": {k: round(v, 3) for k, v in raw_caps.items()},
                "effective_mission_capacity_rps": {k: (round(v, 3) if math.isfinite(v) else None) for k, v in effective_caps.items()},
                "stage_utilization": {k: round(v, 6) for k, v in effective_util.items()},
                "sat_shared_crossing_fraction": round(sat_frac, 6),
                "sat_average_committee_votes": round(avg_sat_votes, 3),
                "scheduler_fraction": round(scheduler_frac, 6),
                "latency": {k: latency_summary(v) for k, v in self.metrics.latencies.items()},
                "avg_receipt_plus_attestation_bytes_assumption": avg_receipt_bytes,
                "receipt_storage_per_day_bytes_estimate": round(storage_day),
                "receipt_storage_per_day_gb_estimate": round(storage_day / 1e9, 3),
                "note": "Synthetic service-time/capacity assumptions, not measured SLO evidence."
            },
            "samples": {
                "receipts": self.metrics.sample_receipts,
                "checkpoints": self.metrics.sample_checkpoints,
            },
        }
        result["verdict"] = self._verdict(result)
        return result

    def _verdict(self, result: dict) -> dict:
        v = result["security"]["violations"]
        hard = sum(v.values())
        safety = "PASS" if hard == 0 else "FAIL"
        cap = result["performance_synthetic"]["synthetic_capacity_rps"]
        capacity = "PASS" if self.demand_rps < cap * 0.75 else "AT_RISK" if self.demand_rps < cap else "FAIL"
        auth = "PASS" if result["authority"]["authority_escape_violations"] == 0 else "FAIL"
        return {
            "constitutional_safety": safety,
            "authority_containment": auth,
            "synthetic_capacity_at_configured_load": capacity,
            "economic_quarantine": "PASS" if result["lifecycle"]["poi_shadow_settlement_power"] == 0 else "FAIL",
            "overall_emulation": "PASS_WITH_DERIVED_PERFORMANCE" if safety == auth == "PASS" and capacity != "FAIL" else "FAIL_OR_REDESIGN_REQUIRED",
        }


def capacity_sweep(scenario: dict, common: dict, global_result: dict) -> List[dict]:
    perf = global_result["performance_synthetic"]
    effective = {k:v for k,v in perf["effective_mission_capacity_rps"].items() if v is not None}
    bottleneck = min(effective, key=effective.get)
    cap = effective[bottleneck]
    points = []
    for frac in [0.10,0.25,0.50,0.70,0.80,0.90,0.95,0.98,1.00,1.10,1.25,1.50]:
        demand = cap * frac
        max_util = frac
        mult = queue_multiplier(max_util)
        points.append({
            "demand_rps": round(demand,1),
            "bottleneck_stage": bottleneck,
            "bottleneck_fraction": frac,
            "max_utilization": round(max_util,4),
            "queue_multiplier_max": round(mult,3),
            "admission_posture": "GREEN" if frac <= 0.70 else "AMBER" if frac < 1.0 else "RED",
        })
    return points


def validate_result(result: dict) -> List[str]:
    errors = []
    if result["truth_label"] != TRUTH:
        errors.append("truth label drift")
    if result["authority"]["authority_escape_violations"] != 0:
        errors.append("authority escape")
    if result["security"]["privacy_violations"] != 0:
        errors.append("privacy leak")
    if result["security"]["double_lease_violations"] != 0:
        errors.append("double lease")
    if result["lifecycle"]["poi_shadow_settlement_power"] != 0:
        errors.append("PoI shadow gained settlement power")
    return errors


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenarios", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    data = json.loads(Path(args.scenarios).read_text())
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    results = []
    all_errors = []
    for sc in data["scenarios"]:
        emu = Emulator(sc, data["common"], data["seed"])
        result = emu.run()
        result["validation_errors"] = validate_result(result)
        if result["validation_errors"]:
            all_errors.extend([f"{sc['id']}: {e}" for e in result["validation_errors"]])
        results.append(result)
        (out / f"{sc['id']}.json").write_text(json.dumps(result, indent=2, sort_keys=True))
    global_sc = next(x for x in data["scenarios"] if x["id"] == "global_1m_derived")
    global_result = next(r for r in results if r["scenario_id"] == "global_1m_derived")
    sweep = capacity_sweep(global_sc, data["common"], global_result)
    bundle = {
        "schema": "bizra.urp.e2e_emulation_bundle.v1",
        "truth_label": TRUTH,
        "scenario_source": os.path.abspath(args.scenarios),
        "results": results,
        "global_1m_capacity_sweep": sweep,
        "validation": {"passed": not all_errors, "errors": all_errors},
    }
    (out / "emulation_results.json").write_text(json.dumps(bundle, indent=2, sort_keys=True))
    print(json.dumps({
        "scenarios": len(results),
        "validation_passed": not all_errors,
        "errors": all_errors,
        "overall": {r["scenario_id"]: r["verdict"]["overall_emulation"] for r in results},
    }, indent=2))
    return 0 if not all_errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
