#!/usr/bin/env python3
import argparse, hashlib, json, math
from pathlib import Path

TRUTH="DERIVED_EMULATION_NOT_RUNTIME_RECEIPT"
BANNED={"human_name","device_id","ip_address","raw_private_data","private_prompt","raw_corpus"}
EXPECTED={"node0_closed_loop","node1_two_human_federation","cluster_100","cluster_1000","cluster_1000_chaos","global_1m_derived"}

def canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()

def dhash(domain,obj):
    h=hashlib.sha256(); h.update(("BIZRA|"+domain+"|v1|").encode()); h.update(canonical(obj)); return h.hexdigest()

def check(cond,msg,errors):
    if not cond: errors.append(msg)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--results',required=True)
    ap.add_argument('--scenarios',required=True)
    args=ap.parse_args()
    bundle=json.loads(Path(args.results).read_text())
    cfg=json.loads(Path(args.scenarios).read_text())
    errors=[]; checks=0
    check(bundle.get('truth_label')==TRUTH,'bundle truth label drift',errors); checks+=1
    ids={r['scenario_id'] for r in bundle.get('results',[])}
    check(ids==EXPECTED,f'scenario set mismatch: {ids}',errors); checks+=1
    mix=sum(cfg['common']['effect_mix'].values())
    check(abs(mix-1.0)<1e-9,f'effect mix != 1 ({mix})',errors); checks+=1
    pol=cfg['common'].get('sat_committee_policy',{})
    check(pol.get('shared_crossing_normal')=='4_of_5','normal SAT committee policy drift',errors); checks+=1
    check(pol.get('shared_crossing_high_risk')=='5_of_7','high-risk SAT committee policy drift',errors); checks+=1
    cp_every=cfg['common']['checkpoint_every_receipts']
    for r in bundle['results']:
        sid=r['scenario_id']; scope=r['scope']; life=r['lifecycle']; auth=r['authority']; sec=r['security']
        check(r['truth_label']==TRUTH,f'{sid}: truth label drift',errors); checks+=1
        check(scope['live_runtime_claim'] is False,f'{sid}: live runtime claim became true',errors); checks+=1
        total=life['missions_completed']+life['missions_refused']+life['execution_failures_safe']
        check(total==scope['missions_simulated'],f'{sid}: mission accounting mismatch {total} != {scope["missions_simulated"]}',errors); checks+=1
        check(life['receipts_registered']==scope['missions_simulated'],f'{sid}: one-receipt-per-mission invariant failed',errors); checks+=1
        expected_cp=math.ceil(life['receipts_registered']/cp_every) if life['receipts_registered'] else 0
        check(life['checkpoints_sealed']==expected_cp,f'{sid}: checkpoint count {life["checkpoints_sealed"]} != {expected_cp}',errors); checks+=1
        check(auth['authority_escape_violations']==0,f'{sid}: authority escape',errors); checks+=1
        check(sec['privacy_violations']==0,f'{sid}: privacy violation',errors); checks+=1
        check(sec['double_lease_violations']==0,f'{sid}: double lease',errors); checks+=1
        check(not sec['violations'],f'{sid}: violations present {sec["violations"]}',errors); checks+=1
        check(life['poi_shadow_settlement_power']==0,f'{sid}: PoI gained settlement power',errors); checks+=1
        controls=sec['controls_triggered']
        for key in ['double_lease_negative_control_blocked','stale_fence_negative_control_blocked','unsafe_byzantine_quorum_fail_closed','economic_settlement_negative_control_blocked']:
            check(controls.get(key,0)>=1,f'{sid}: missing negative control {key}',errors); checks+=1
        # Sample receipt cryptographic re-derivation (simulated domain-hash/signature only).
        for j,e in enumerate(r['samples']['receipts']):
            payload=e['payload']
            check(not (BANNED & set(payload)),f'{sid}: sample receipt {j} contains banned fields',errors); checks+=1
            rh=dhash('EXECUTION_RECEIPT',payload)
            check(rh==e['receipt_hash'],f'{sid}: sample receipt {j} hash mismatch',errors); checks+=1
            node=int(payload['node_pseudonym'].split('-')[-1])
            sig=dhash('SIM_SIGNATURE',{'key':f'sim-key-{node}','receipt_hash':rh})
            check(sig==e['signature'],f'{sid}: sample receipt {j} signature mismatch',errors); checks+=1
        prev=None
        for j,cp in enumerate(r['samples']['checkpoints']):
            body=dict(cp); got=body.pop('checkpoint_hash')
            check(dhash('EPOCH_CHECKPOINT',body)==got,f'{sid}: checkpoint {j} hash mismatch',errors); checks+=1
            if prev is not None:
                check(cp['previous_checkpoint_hash']==prev,f'{sid}: checkpoint sample chain break {j}',errors); checks+=1
            prev=got
    g=next(r for r in bundle['results'] if r['scenario_id']=='global_1m_derived')
    check(g['scope']['nodes_represented']==1_000_000,'global: nodes represented != 1M',errors); checks+=1
    check(g['scope']['nodes_simulated']<g['scope']['nodes_represented'],'global: not an extrapolation',errors); checks+=1
    check(g['performance_synthetic']['synthetic_capacity_rps']>g['performance_synthetic']['represented_demand_rps'],'global: configured synthetic demand exceeds capacity',errors); checks+=1
    sweep=bundle['global_1m_capacity_sweep']
    check(any(x['admission_posture']=='RED' for x in sweep if x['bottleneck_fraction']>=1.0),'global: capacity sweep has no RED overload region',errors); checks+=1
    out={'schema':'bizra.urp.e2e_emulation_verification.v1','truth_label':'INDEPENDENT_MECHANICAL_VERIFICATION_OF_DERIVED_EMULATION','checks':checks,'passed':not errors,'errors':errors}
    print(json.dumps(out,indent=2,sort_keys=True))
    return 0 if not errors else 2

if __name__=='__main__': raise SystemExit(main())
