#!/usr/bin/env python3
import json,sys
from pathlib import Path

def main(inp,out):
    d=json.loads(Path(inp).read_text())
    g=next(r for r in d['results'] if r['scenario_id']=='global_1m_derived')
    perf=g['performance_synthetic']; auth=g['authority']; m=g['scope']['missions_simulated']
    sat_frac=perf['sat_shared_crossing_fraction']; avg=perf['sat_average_committee_votes']
    high_frac=max(0,min(1,(avg-5.0)/2.0))
    high_mission=sat_frac*high_frac; normal_mission=sat_frac*(1-high_frac)
    raw_sat=perf['raw_stage_task_capacity_rps']['sat']
    other=[v for k,v in perf['effective_mission_capacity_rps'].items() if k!='sat' and v is not None]
    fast=[]
    for f in [0,0.25,0.5,0.75,0.9]:
        votes_per_mission=high_mission*7 + normal_mission*(5*(1-f)+2*f)
        sat_cap=raw_sat/votes_per_mission
        total=min(other+[sat_cap])
        fast.append({'mechanical_fast_path_fraction_of_normal_shared':f,'sat_votes_per_total_mission':round(votes_per_mission,4),'sat_effective_mission_capacity_rps':round(sat_cap,1),'system_effective_capacity_rps':round(total,1),'capacity_gain_vs_current_x':round(total/perf['synthetic_capacity_rps'],3)})
    b=auth['approval_breakdown']
    mission_rate=perf['represented_demand_rps']/g['scope']['nodes_represented']
    def row(name, hard_batch=1, lease_mult=1, share_mult=1, economy_failfast=False):
        approvals=(b.get('authority_lease_issue',0)/lease_mult + b.get('wisdom_share_lease_issue',0)/share_mult + b.get('fresh_hard_effect',0)/hard_batch + (0 if economy_failfast else b.get('fresh_economic_intent',0)))
        rate=approvals/m
        return {'variant':name,'approval_rate_per_mission':round(rate,6),'approvals_per_node_per_day':round(rate*mission_rate*86400,3),'reduction_vs_microconsent_pct':round((1-rate/auth['baseline_approval_rate_per_mission'])*100,3)}
    attention=[
      row('current_emulation'),
      row('fail_fast_economy',economy_failfast=True),
      row('fail_fast_plus_manifest_batch_8',hard_batch=8,economy_failfast=True),
      row('bounded_lease_4x_share_4x_manifest_batch_16',hard_batch=16,lease_mult=4,share_mult=4,economy_failfast=True),
    ]
    storage=[]
    for rps in [1000,5000,20000,40000]:
        for bytes_per in [1500,2270,3500,5000]:
            storage.append({'receipt_rps':rps,'bytes_per_receipt':bytes_per,'tb_per_day_decimal':round(rps*bytes_per*86400/1e12,3),'pb_per_year_decimal':round(rps*bytes_per*86400*365/1e15,3)})
    outd={'schema':'bizra.urp.emulation_sensitivity.v1','truth_label':'DERIVED_SENSITIVITY_NOT_RUNTIME_PROOF','global_1m_base':{'sat_shared_crossing_fraction':sat_frac,'sat_average_committee_votes':avg,'inferred_high_risk_fraction_of_shared':round(high_frac,4),'raw_sat_task_capacity_rps':raw_sat,'current_system_capacity_rps':perf['synthetic_capacity_rps'],'configured_demand_rps':perf['represented_demand_rps']},'sat_fast_path_sensitivity':fast,'human_attention_sensitivity':attention,'receipt_storage_sensitivity':storage,'notes':['Mechanical fast path assumes two independent deterministic verifier implementations for eligible low-risk shared crossings; it is a proposal, not V3 proof.','Manifest batching means one fresh HumanGrant names a finite immutable list of hard effects; it is not self-expanding authority.','Larger leases must remain time-, scope-, path-, endpoint-, and budget-bounded and revocable.']}
    Path(out).write_text(json.dumps(outd,indent=2,sort_keys=True))
    print(json.dumps(outd,indent=2,sort_keys=True))
if __name__=='__main__': main(sys.argv[1],sys.argv[2])
