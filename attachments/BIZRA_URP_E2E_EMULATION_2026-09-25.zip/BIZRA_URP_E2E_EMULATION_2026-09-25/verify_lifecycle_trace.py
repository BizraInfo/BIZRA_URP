#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path

def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def H(domain,x):
    h=hashlib.sha256(); h.update(f'BIZRA|{domain}|v1|'.encode()); h.update(canon(x)); return h.hexdigest()

def main(p):
    d=json.loads(Path(p).read_text()); errs=[]
    last=0
    for s in d['steps']:
        body=dict(s); got=body.pop('step_hash')
        if s['seq'] != last+1: errs.append(f'seq gap at {s["seq"]}')
        last=s['seq']
        if H('LIFECYCLE_STEP',body)!=got: errs.append(f'step hash mismatch {s["seq"]}')
    body=dict(d); got=body.pop('trace_hash')
    if H('LIFECYCLE_TRACE',body)!=got: errs.append('trace hash mismatch')
    if not all(d['final_invariants'].values()): errs.append('final invariant false')
    required={'NODE0_ACTIVATION','DEMA_INTENT','PAT_PLAN','HUMAN_AUTHORITY','MEMBRANE','NODE1_REGISTRY','RESOURCE_OFFER','SCHEDULER','WORKER_FAILURE','RECOVERY','SAT_COMMITTEE','EXECUTION','RECEIPT','TRANSPARENCY','CHECKPOINT','BLOCKTREE','BLOCKGRAPH','UKE','POI','RESOURCE_RELEASE','RELATIONSHIP_REVOCATION','FINAL_INVARIANTS'}
    got_stages={s['stage'] for s in d['steps']}
    if got_stages!=required: errs.append('stage set mismatch')
    print(json.dumps({'schema':'bizra.urp.lifecycle_trace_verify.v1','checks':len(d['steps'])+3,'passed':not errs,'errors':errs,'trace_hash':got},indent=2,sort_keys=True))
    return 0 if not errs else 2
if __name__=='__main__': raise SystemExit(main(sys.argv[1]))
