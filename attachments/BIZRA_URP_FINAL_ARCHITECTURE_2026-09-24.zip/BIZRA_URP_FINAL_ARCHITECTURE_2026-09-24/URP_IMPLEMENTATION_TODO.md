# BIZRA URP Implementation TODO

**Ordering law:** canon convergence before runtime expansion; local closed loop before network opening; measured smaller-scale load before extrapolated planetary claims.

## P0 — Canon convergence and false-GREEN elimination

- [ ] Create `URP_FINAL_ARCHITECTURE_V3.md` and point all derivative topology docs to it + Topology Canon.
- [ ] Mark the per-human-URP model in `URP_ARCHITECTURE_v2.md` as superseded for topology decisions; preserve provenance.
- [ ] Update `bizra-urp-blocktree` visual to label URP **logical singleton / physically distributed**; keep no-node-P2P invariant.
- [ ] Accept a single SAT-role ADR and machine enum; resolve Validator/Oracle/Mediator/Archivist/Sentinel vs Guardian/Reasoner/Builder/Critic/Archivist.
- [ ] Replace prototype truth labels such as `NODE0_5SAT_URP_LAUNCHED_AND_LOCKED` when execution is only a declaration; truth label must encode `DECLARED_ONLY` / `PREVIEW_ONLY`.
- [ ] Standardize receipt-chain hash vocabulary. Remove ambiguous BLAKE3-vs-SHA256 descriptions unless multiple domains are intentional and explicitly named.
- [ ] Add `canon-check` assertions for: one shared URP, PAT local, SAT shared, no direct node P2P, second device != new node.
- [ ] Add documentation drift test that rejects topology sentences inconsistent with the registry.

**P0 DoD:** zero known topology contradictions across canon, schemas, code comments, CLI help, tests, and public diagrams.

## P1 — Pure contracts first (no network)

- [ ] Implement versioned schemas: `NodePassport`, `AuthorityLease`, `MissionEnvelope`, `ResourceOffer`, `ResourceLease`, `ExecutionReceipt`, `VerifierAttestation`, `WisdomObject`, `ImpactRecord`, `EpochCheckpoint`.
- [ ] Introduce deterministic canonicalization profile (JCS for JSON, deterministic CBOR option).
- [ ] Add domain-separated hash inputs and explicit `hash_alg` / `sig_alg` / `key_id`.
- [ ] Implement monotonic sequence + nonce + expiry replay protection.
- [ ] Implement exact enum for truth/evidence labels.
- [ ] Implement pure state-machine transition functions; invalid transitions fail closed.
- [ ] Implement independent verifier package that does not import producer-only mutation code.

**P1 DoD:** deterministic contract vectors pass in JS/Rust implementations from identical fixtures.

## P2 — Authority lease + local mission scheduler

- [ ] Add `AuthorityGrant` / `AuthorityLease` proposal path behind explicit typed operator consent.
- [ ] Define effect classes: OBSERVE, REMEMBER, PROPOSE, REVERSIBLE_LOCAL, GOVERNED_MUTATION, IRREVERSIBLE_EXTERNAL.
- [ ] Encode hard re-consent classes that leases can never auto-authorize.
- [ ] Enforce lease budgets: time, attempts, CPU/GPU, bytes, endpoints, files/paths, data classes, cost, max parallelism.
- [ ] Add lease revocation and safe-point cancellation.
- [ ] Integrate mission queue with local loopback resource scheduler.
- [ ] Produce execution receipt + rollback/recovery reference for each governed mutation.

**P2 DoD:** one clean Node0 campaign performs multiple bounded low-risk steps under one lease; an out-of-scope step is refused and receipted; revocation halts subsequent work.

## P3 — Receipt transparency + BlockTree/BlockGraph

- [ ] Define immutable signed-statement receipt envelope.
- [ ] Separate issuer signature from transparency/checkpoint receipt.
- [ ] Implement shard/local append log and Merkle accumulator.
- [ ] Implement inclusion proof and consistency proof verification.
- [ ] Implement BlockTree single-lineage-parent rule.
- [ ] Implement typed BlockGraph links: `verification`, `adoption`, `impact`, `dependency`, `supersession`, `challenge`.
- [ ] Seal epoch checkpoint containing prior checkpoint hash, shard roots, canon hash, policy hash, revocation root, key-set id.
- [ ] Add offline verifier and replay-from-checkpoint tool.

**P3 DoD:** independent verifier can prove a receipt was included in an epoch without trusting the producer process.

## P4 — Shared URP single-region alpha

- [ ] Build URP ingress/membrane gateway; default deny.
- [ ] Add pseudonymous node registry and Node0 shared-URP registration flow.
- [ ] Add internal workload identity and mTLS.
- [ ] Add resource offer directory and scheduler.
- [ ] Add ephemeral SAT worker pool mapped to logical SAT identities.
- [ ] Add per-tenant quotas/rate limits/backpressure.
- [ ] Add receipt/transparency service.
- [ ] Add OTel traces/metrics/logs with privacy filters.
- [ ] Keep UKE/PoI/economy in shadow or stub mode unless their separate gates are met.

**P4 DoD:** Node0 crosses the real membrane to a shared-alpha URP and receives a verifiable result with no raw private-data leakage and no direct peer addressing.

## P5 — Node1 two-sovereign-human pilot

- [ ] Registry assigns ordinal 1; no manual/skipped/duplicate ordinal.
- [ ] Mutual capability manifests and separate explicit consents.
- [ ] No disclosure of human identity by default; only pseudonymous node/workload claims.
- [ ] Resource offer -> match -> lease -> execute -> verify -> release.
- [ ] Disconnect/revoke leaves local Node0 and Node1 sovereign.
- [ ] Negative tests: replay, stale key, bad policy hash, privacy-class mismatch, over-budget request, direct node endpoint attempt.

**P5 DoD:** two physical sovereign nodes complete one cross-node benefit through URP only; packet/application evidence demonstrates no direct Node0<->Node1 control channel.

## P6 — 100 / 1,000-node measured synthetic cluster

- [ ] Create scenario YAML/JSON external to source; remove hard-coded 32GB/500GB/8-core assumptions from the model.
- [ ] Record hardware, commit, scenario hash, random seed, duration, load shape.
- [ ] Measure p50/p95/p99 latency, admission delay, scheduler throughput, receipt rate, checkpoint time, verifier rate, bytes/receipt, CPU/RAM/GPU, failure recovery.
- [ ] Inject node churn, network partitions, duplicate messages, clock skew, worker death, shard failover, revocation storms.
- [ ] Verify no double resource lease and no authority escape under chaos.

**P6 DoD:** benchmark report is reproducible and explicitly distinguishes MEASURED from DERIVED.

## P7 — UKE / House of Wisdom governed sharing

- [ ] Implement WisdomObject lifecycle: OBSERVED -> CANDIDATE -> CHALLENGED -> SUPPORTED -> ADMITTED -> ACTIVE -> SUSPENDED -> SUPERSEDED/REVOKED.
- [ ] Require provenance, evidence class, independence level, scope, TTL/review triggers.
- [ ] Require SAT verification + operator sharing consent before shared admission.
- [ ] Never ship raw private corpus; share only explicitly cleared artifacts/claims.
- [ ] Add poisoning/contradiction/challenge workflows.

## P8 — PoI shadow ledger

- [ ] Define impact evidence graph and anti-self-dealing rules.
- [ ] Distinguish contribution receipt from impact attestation from reward eligibility.
- [ ] Require independent verifier diversity for high-impact claims.
- [ ] Run shadow scoring with zero settlement power.
- [ ] Red-team collusion, Sybil behavior, circular attestation, resource inflation, replay, and popularity bias.

## P9 — Multi-region URP

- [ ] Global directory maps node pseudonym -> home ingress/shard without exposing private identity.
- [ ] Regional schedulers own local admission; global layer handles placement policy, not every mission event.
- [ ] Replicate checkpoints/revocations strongly enough to preserve safety; tolerate regional partition with fail-closed authority semantics.
- [ ] Define recovery point/time objectives and tested regional evacuation.

## P10 — 1M-node validation program

- [ ] Keep `global_1m` deterministic design emulation, but externalize assumptions and produce confidence intervals.
- [ ] Model 1M humans = 7M PAT local + 5M SAT logical identities, not 12M always-on centralized processes.
- [ ] Run high-fidelity distributed load at the largest physically measured scale available and calibrate the emulator to measurements.
- [ ] Produce sensitivity analysis for mission mix, consent/lease behavior, receipt sizes, resource heterogeneity, churn, adversary rate, and verifier quorum.
- [ ] Establish safe capacity envelope; no claim of “1M live nodes” without 1M live nodes.

## P11 — Independent audit / production gate

- [ ] Independent cryptographic verification.
- [ ] Threat-model review + red-team.
- [ ] SBOM, dependency pinning, provenance, signed builds.
- [ ] Key rotation and revocation drill.
- [ ] Disaster recovery from checkpoints.
- [ ] Privacy review and data-retention policy.
- [ ] Legal/Shariah boundaries for any economic/public-financial capability.
- [ ] External operator reproduces clean-room install + verification.
