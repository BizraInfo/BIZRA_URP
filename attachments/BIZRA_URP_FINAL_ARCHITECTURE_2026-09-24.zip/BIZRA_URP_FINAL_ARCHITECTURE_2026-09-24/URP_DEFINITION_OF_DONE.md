# BIZRA URP Definition of Done

**Rule:** a green checkbox requires proof from the exact build/environment under evaluation. A design artifact is never a runtime receipt.

## A. Architecture/Canon DoD

- [ ] Current Topology Canon and machine registry agree on one shared logical URP.
- [ ] PAT-7 is local per sovereign human Node; DEMA is the human-facing surface.
- [ ] SAT canonical roster is singular, versioned, and shared-URP-side.
- [ ] No direct node-to-node application/control route exists.
- [ ] Companion devices do not mint new node ordinals.
- [ ] URP physical sharding is explicitly an implementation detail of one logical system.
- [ ] All deprecated architecture documents are marked superseded without erasing provenance.
- [ ] Truth labels distinguish DECLARED, MEASURED, DERIVED, PROPOSED, DESIGNED_NOT_LIVE.

## B. Contract/Crypto DoD

- [ ] Every cross-boundary object is schema-versioned and canonicalizable.
- [ ] Hash/signature input is deterministic across two independent implementations.
- [ ] Receipt has issuer, subject, policy hash, canon hash, prior/stream sequence, timestamps/expiry where applicable, algorithms, key id, payload hash, and signature.
- [ ] Replay protection rejects duplicate nonce/sequence and expired envelopes.
- [ ] Verification is read-only and independently runnable.
- [ ] Key rotation and revocation are tested with old/new overlap and stale-key rejection.
- [ ] Large/private payloads can be represented by hashes without sending raw data to transparency infrastructure.

## C. Node0 Local Closed-Loop DoD

The existing flagship DoD remains foundational. Additionally:

- [ ] Clean Node0 executes deterministic mission state machine from proposal through verification without network dependency.
- [ ] Authority scope is explicit; an out-of-scope action is refused.
- [ ] Receipt chain/checkpoint can be replayed from clean state.
- [ ] Local private data remains local unless a specific share action is consented.
- [ ] UI/CLI never claims shared URP runtime is live when operating loopback/preview.

## D. Shared-URP Alpha DoD

- [ ] One logical URP is deployed across at least three failure domains/process groups for the alpha test; loss of one does not silently create two authorities.
- [ ] Node0 authenticates to membrane; URP workloads authenticate with short-lived workload identities.
- [ ] Mission admission binds authority lease + capability + policy version + resource requirements.
- [ ] Scheduler creates an exclusive ResourceLease; duplicate lease for a scarce unit is impossible under tested race conditions.
- [ ] SAT verifier executes under a canonical logical identity and emits a signed attestation.
- [ ] ExecutionReceipt enters transparency log and yields verifiable inclusion proof.
- [ ] OpenTelemetry correlation joins mission -> authority lease -> resource lease -> SAT attestation -> receipt -> checkpoint without logging raw private payloads.
- [ ] Service outage, worker death, and message duplication do not bypass authority or create double settlement.

## E. Node1 DoD

- [ ] Node1 is a second human and receives registry-assigned ordinal 1.
- [ ] Both sides give explicit consent to the bounded relationship.
- [ ] All interaction routes through URP; no hidden P2P back channel.
- [ ] Each node can revoke/disconnect without losing local state or identity.
- [ ] A cross-node mission can consume an opt-in resource and return a verified result without exposing operator identity or raw private data.
- [ ] Privacy leakage test finds no IP/device/human identity in application receipts unless deliberately included under policy.

## F. BlockTree / BlockGraph DoD

- [ ] Every lineage block has exactly one lineage parent except genesis.
- [ ] Cross-links are typed and cannot masquerade as lineage.
- [ ] Cross-link target hashes must exist or be explicitly marked unresolved/quarantined.
- [ ] Epoch checkpoint commits all accepted shard roots and policy/canon/revocation roots.
- [ ] Independent verifier validates inclusion and checkpoint continuity offline.
- [ ] Equivocation/fork test is detected and blocks settlement/authority promotion.

## G. Resource Pool DoD

- [ ] ResourceOffer records owner pseudonym, resource type, capacity, constraints, privacy class, allowed workloads, attestation class, region/locality, TTL, and consent receipt.
- [ ] Scheduler applies quota/fair-share/backpressure, not first-come extraction.
- [ ] ResourceLease is exclusive where required and expires automatically.
- [ ] Failure releases/recovers leases deterministically.
- [ ] No contribution is assumed opt-in from mere node membership.
- [ ] Raw resource telemetry cannot reveal private content.

## H. UKE / Wisdom DoD

- [ ] No shared knowledge enters ACTIVE directly from model output.
- [ ] Evidence/provenance and challenge history are preserved.
- [ ] Human sharing consent and SAT/system verification are independently represented.
- [ ] Promotion, suspension, supersession, and revocation are receipted.
- [ ] Poisoning simulation demonstrates quarantine and rollback.

## I. PoI Shadow DoD

- [ ] Impact evidence is distinguishable from execution success.
- [ ] Self-attestation alone cannot create reward eligibility.
- [ ] Circular/collusive attestations are detected or discounted by explicit policy.
- [ ] Shadow results do not mint or transfer economic value.
- [ ] Counterfactual scoring is reproducible from receipts.

## J. Performance / Reliability DoD

All metrics require explicit SLO values accepted before the corresponding release. Minimum measurement set:

- p50/p95/p99 ingress latency
- admission throughput
- scheduler placement latency
- receipt append latency
- receipt verification throughput
- checkpoint seal latency
- recovery time after worker/shard loss
- replay/rebuild time
- bytes per receipt and bytes per checkpoint
- CPU/RAM/GPU per 1k concurrent missions
- queue depth/backpressure behavior
- rejection/refusal rate by reason
- privacy-policy violations (must be zero in acceptance suite)
- authority-escape violations (must be zero)
- double-lease violations (must be zero)

## K. 1M-Node Validation DoD

A one-million-node design claim is valid only when all of the following are true:

- [ ] Emulator is deterministic for a fixed scenario/seed.
- [ ] Every assumption is in a versioned scenario file, not hidden in code.
- [ ] Extrapolation is labeled DERIVED and carries uncertainty/sensitivity analysis.
- [ ] Emulator is calibrated against measured 100/1,000/maximum-available physical-node runs.
- [ ] SAT count is represented as logical identities/capacity; worker residency is separately modeled.
- [ ] Authority-lease model demonstrates bounded human-attention growth; no unbounded per-microstep approval queue.
- [ ] Receipt/checkpoint architecture demonstrates sublinear/global-batched coordination rather than per-event global serialization.
- [ ] Adversarial scenarios cover Sybil, collusion, replay, scheduler poisoning, resource fraud, network partition, key compromise, and Byzantine verifier behavior.
- [ ] Report explicitly states what is MEASURED vs DERIVED vs UNKNOWN.

**No-false-GREEN rule:** this DoD does not permit the phrase `1M live nodes` unless one million distinct live nodes were actually observed and independently counted.
