#!/usr/bin/env node
/**
 * BIZRA URP V1 contract reference validator.
 *
 * DESIGN ONLY. This file validates structural invariants and emits the proposed
 * spec. It does not sign, authorize, connect, mutate BIZRA state, or prove a
 * live URP exists.
 *
 * Usage:
 *   node urp-contracts-v1.mjs spec
 *   node urp-contracts-v1.mjs validate <Kind> <json-file>
 *   node urp-contracts-v1.mjs self-test
 */

import { readFile } from "node:fs/promises";
import process from "node:process";

const KINDS = Object.freeze([
  "NodePassport",
  "AuthorityLease",
  "MissionEnvelope",
  "ResourceOffer",
  "ResourceLease",
  "ExecutionReceipt",
  "VerifierAttestation",
  "EpochCheckpoint",
]);

const SAT_ROLES_CURRENT_REPO_CANON = Object.freeze([
  "S1_VALIDATOR",
  "S2_ORACLE_FROZEN",
  "S3_MEDIATOR",
  "S4_ARCHIVIST",
  "S5_SENTINEL",
]);

const HARD_RECONSENT_EFFECTS = Object.freeze([
  "FEDERATION_ENROLLMENT",
  "PUBLIC_PUBLICATION",
  "KEY_AUTHORITY_CHANGE",
  "ECONOMIC_SETTLEMENT",
  "TOKEN_MINT_BURN_TRANSFER",
  "CANON_CHANGE",
  "IDENTITY_ORDINAL_CHANGE",
  "DESTRUCTIVE_EXTERNAL_EFFECT",
  "PRIVACY_DISCLOSURE_WIDENING",
  "AUTHORITY_POLICY_CHANGE",
]);

export const URP_SPEC = Object.freeze({
  schema: "bizra.urp.contract_spec.v1",
  truth_label: "PROPOSED_DESIGN_NOT_RUNTIME_RECEIPT",
  topology: Object.freeze({
    node_model: "ONE_HUMAN_ONE_SOVEREIGN_NODE",
    urp_count: "ONE_LOGICAL_SHARED_URP",
    physical_urp: "DISTRIBUTED_SHARDED_INTERNAL_IMPLEMENTATION",
    pat_location: "LOCAL_PER_HUMAN_NODE",
    sat_location: "SHARED_URP",
    crossing: "PAT_TO_MEMBRANE_FATE_TO_URP_SAT",
    direct_node_to_node_control: false,
  }),
  scale: Object.freeze({
    pat_per_node: 7,
    sat_logical_identities_contributed_per_node: 5,
    sat_worker_residency: "ELASTIC_NOT_ONE_PER_LOGICAL_IDENTITY",
  }),
  sat_roles_current_repo_canon: SAT_ROLES_CURRENT_REPO_CANON,
  hard_reconsent_effects: HARD_RECONSENT_EFFECTS,
  serialization: Object.freeze({
    json_canonicalization: "RFC8785_JCS_RECOMMENDED",
    compact_encoding: "RFC8949_DETERMINISTIC_CBOR_RECOMMENDED",
    explicit_algorithm_identifiers: true,
  }),
  receipt_model: Object.freeze({
    local_or_shard_ordered_streams: true,
    global_every_event_consensus: false,
    epoch_checkpoint_roots: true,
    blocktree_single_lineage_parent: true,
    blockgraph_typed_cross_links: true,
  }),
});

const REQUIRED = Object.freeze({
  NodePassport: [
    "schema", "schema_version", "node_id", "node_ordinal", "primary_or_companion",
    "public_key_refs", "capability_manifest_hash", "canon_version", "created_at", "status", "issuer", "signature",
  ],
  AuthorityLease: [
    "schema", "schema_version", "lease_id", "human_grant_id", "node_id", "subject",
    "allowed_effects", "forbidden_effects", "resource_budgets", "valid_from", "expires_at",
    "max_attempts", "max_parallelism", "revocation_epoch", "nonce", "policy_hash", "canon_hash",
    "human_consent_receipt_hash", "signature",
  ],
  MissionEnvelope: [
    "schema", "schema_version", "mission_id", "node_id", "intent_hash", "objective", "success_criteria",
    "required_capabilities", "required_resources", "data_disclosure_manifest", "risk_class", "requested_effects",
    "authority_lease_id", "policy_hash", "canon_hash", "created_at", "expires_at", "trace_id", "signature",
  ],
  ResourceOffer: [
    "schema", "schema_version", "offer_id", "node_id_pseudonym", "resource_type", "capacity", "privacy_class",
    "allowed_workloads", "prohibited_workloads", "attestation_class", "availability_window", "lease_ttl_max",
    "consent_receipt_hash", "expires_at", "signature",
  ],
  ResourceLease: [
    "schema", "schema_version", "resource_lease_id", "offer_id", "mission_id", "allocated_capacity", "start_at",
    "expires_at", "exclusive_keys", "worker_identity", "scheduler_policy_hash", "fencing_token", "state", "signature",
  ],
  ExecutionReceipt: [
    "schema", "schema_version", "receipt_id", "stream_id", "sequence", "prev_receipt_hash", "mission_id",
    "authority_lease_id", "issuer_identity", "subject_hash", "input_commitments", "output_commitments", "effect_class",
    "effect_summary", "truth_label", "evidence_class", "policy_hash", "canon_hash", "started_at", "ended_at", "nonce",
    "hash_alg", "sig_alg", "key_id", "signature",
  ],
  VerifierAttestation: [
    "schema", "schema_version", "attestation_id", "subject_hash", "sat_identity_id", "verifier_workload_id",
    "verifier_policy_hash", "independence_group", "checks", "verdict", "reason_codes", "evidence_hashes", "issued_at", "signature",
  ],
  EpochCheckpoint: [
    "schema", "schema_version", "checkpoint_id", "epoch", "previous_checkpoint_hash", "shard_roots", "canon_hash",
    "policy_set_hash", "revocation_root", "key_set_hash", "node_registry_root", "created_at", "quorum_attestations", "signature_set",
  ],
});

function nonEmptyString(value) {
  return typeof value === "string" && value.trim().length > 0;
}

function isoTime(value) {
  if (!nonEmptyString(value)) return false;
  const d = new Date(value);
  return Number.isFinite(d.getTime()) && value.includes("T");
}

function fail(errors, code, path, detail) {
  errors.push({ code, path, detail });
}

function requireFields(kind, obj, errors) {
  for (const field of REQUIRED[kind] ?? []) {
    if (!Object.prototype.hasOwnProperty.call(obj, field)) {
      fail(errors, "MISSING_REQUIRED_FIELD", field, `${kind}.${field} is required`);
    }
  }
}

function validateCommonTemporal(obj, errors) {
  for (const key of ["created_at", "valid_from", "start_at", "started_at", "issued_at"]) {
    if (key in obj && !isoTime(obj[key])) fail(errors, "INVALID_TIME", key, "must be ISO-8601-like date-time");
  }
  for (const key of ["expires_at", "ended_at"]) {
    if (key in obj && !isoTime(obj[key])) fail(errors, "INVALID_TIME", key, "must be ISO-8601-like date-time");
  }
  if (obj.valid_from && obj.expires_at && new Date(obj.expires_at) <= new Date(obj.valid_from)) {
    fail(errors, "NON_POSITIVE_VALIDITY", "expires_at", "expires_at must be after valid_from");
  }
  if (obj.start_at && obj.expires_at && new Date(obj.expires_at) <= new Date(obj.start_at)) {
    fail(errors, "NON_POSITIVE_LEASE", "expires_at", "expires_at must be after start_at");
  }
  if (obj.started_at && obj.ended_at && new Date(obj.ended_at) < new Date(obj.started_at)) {
    fail(errors, "NEGATIVE_DURATION", "ended_at", "ended_at must not precede started_at");
  }
}

function validateNodePassport(obj, errors) {
  if (!Number.isInteger(obj.node_ordinal) || obj.node_ordinal < 0) {
    fail(errors, "INVALID_NODE_ORDINAL", "node_ordinal", "must be a non-negative integer");
  }
  if (!["PRIMARY", "COMPANION"].includes(obj.primary_or_companion)) {
    fail(errors, "INVALID_NODE_KIND", "primary_or_companion", "must be PRIMARY or COMPANION");
  }
  if (obj.primary_or_companion === "COMPANION" && !nonEmptyString(obj.primary_node_id)) {
    fail(errors, "COMPANION_WITHOUT_PRIMARY", "primary_node_id", "companion must bind to a primary Node identity");
  }
}

function validateAuthorityLease(obj, errors) {
  if (!Array.isArray(obj.allowed_effects)) fail(errors, "INVALID_EFFECT_SET", "allowed_effects", "must be an array");
  if (!Array.isArray(obj.forbidden_effects)) fail(errors, "INVALID_EFFECT_SET", "forbidden_effects", "must be an array");
  const allowed = new Set(Array.isArray(obj.allowed_effects) ? obj.allowed_effects : []);
  for (const hard of HARD_RECONSENT_EFFECTS) {
    if (allowed.has(hard)) {
      fail(errors, "HARD_EFFECT_CANNOT_BE_LEASE_AUTO_AUTHORIZED", "allowed_effects", hard);
    }
  }
  if (!Number.isInteger(obj.max_attempts) || obj.max_attempts < 1) fail(errors, "INVALID_BUDGET", "max_attempts", "must be >= 1");
  if (!Number.isInteger(obj.max_parallelism) || obj.max_parallelism < 1) fail(errors, "INVALID_BUDGET", "max_parallelism", "must be >= 1");
  if (!nonEmptyString(obj.human_consent_receipt_hash)) {
    fail(errors, "MISSING_HUMAN_AUTHORITY_EVIDENCE", "human_consent_receipt_hash", "lease must bind to human authority evidence");
  }
}

function validateMissionEnvelope(obj, errors) {
  if (!Array.isArray(obj.success_criteria) || obj.success_criteria.length === 0) {
    fail(errors, "MISSING_SUCCESS_CRITERIA", "success_criteria", "mission needs at least one testable criterion");
  }
  if (!nonEmptyString(obj.authority_lease_id)) {
    fail(errors, "NO_AUTHORITY_BINDING", "authority_lease_id", "mission must bind an authority lease/grant");
  }
}

function validateResourceLease(obj, errors) {
  if (!Number.isInteger(obj.fencing_token) || obj.fencing_token < 1) {
    fail(errors, "INVALID_FENCING_TOKEN", "fencing_token", "must be a positive monotonic token");
  }
}

function validateExecutionReceipt(obj, errors) {
  if (!Number.isInteger(obj.sequence) || obj.sequence < 0) fail(errors, "INVALID_SEQUENCE", "sequence", "must be >= 0");
  if (obj.sequence === 0 && obj.prev_receipt_hash !== null) {
    fail(errors, "GENESIS_PREV_HASH", "prev_receipt_hash", "sequence 0 must have null previous hash");
  }
  if (obj.sequence > 0 && !nonEmptyString(obj.prev_receipt_hash)) {
    fail(errors, "MISSING_PREV_HASH", "prev_receipt_hash", "non-genesis receipt must link previous receipt hash");
  }
  if (!nonEmptyString(obj.hash_alg) || !nonEmptyString(obj.sig_alg) || !nonEmptyString(obj.key_id)) {
    fail(errors, "CRYPTO_PROFILE_MISSING", "hash_alg/sig_alg/key_id", "algorithms and key id are mandatory");
  }
}

function validateVerifierAttestation(obj, errors) {
  if (!["PASS", "FAIL", "CHALLENGE", "UNKNOWN"].includes(obj.verdict)) {
    fail(errors, "INVALID_VERDICT", "verdict", "unknown verifier verdict");
  }
  if (!Array.isArray(obj.checks) || obj.checks.length === 0) {
    fail(errors, "EMPTY_VERIFIER_CHECKS", "checks", "attestation must state performed checks");
  }
}

function validateEpochCheckpoint(obj, errors) {
  if (!Number.isInteger(obj.epoch) || obj.epoch < 0) fail(errors, "INVALID_EPOCH", "epoch", "must be >= 0");
  if (!Array.isArray(obj.shard_roots) || obj.shard_roots.length === 0) {
    fail(errors, "NO_SHARD_ROOTS", "shard_roots", "checkpoint must commit at least one shard root");
  }
  if (!Array.isArray(obj.quorum_attestations) || obj.quorum_attestations.length === 0) {
    fail(errors, "NO_CHECKPOINT_ATTESTATION", "quorum_attestations", "checkpoint must carry authority attestations");
  }
}

export function validate(kind, obj) {
  const errors = [];
  if (!KINDS.includes(kind)) {
    return { ok: false, kind, errors: [{ code: "UNKNOWN_KIND", path: "kind", detail: `Allowed: ${KINDS.join(", ")}` }] };
  }
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) {
    return { ok: false, kind, errors: [{ code: "NOT_OBJECT", path: "$", detail: "payload must be a JSON object" }] };
  }

  requireFields(kind, obj, errors);
  validateCommonTemporal(obj, errors);

  if (kind === "NodePassport") validateNodePassport(obj, errors);
  if (kind === "AuthorityLease") validateAuthorityLease(obj, errors);
  if (kind === "MissionEnvelope") validateMissionEnvelope(obj, errors);
  if (kind === "ResourceLease") validateResourceLease(obj, errors);
  if (kind === "ExecutionReceipt") validateExecutionReceipt(obj, errors);
  if (kind === "VerifierAttestation") validateVerifierAttestation(obj, errors);
  if (kind === "EpochCheckpoint") validateEpochCheckpoint(obj, errors);

  return {
    schema: "bizra.urp.reference_validation.v1",
    truth_label: "STRUCTURAL_VALIDATION_ONLY_NOT_AUTHORIZATION",
    ok: errors.length === 0,
    kind,
    errors,
  };
}

function selfTest() {
  const badLease = {
    schema: "bizra.urp.authority_lease",
    schema_version: "1.0",
    lease_id: "lease-test",
    human_grant_id: "grant-test",
    node_id: "node0",
    subject: "test",
    allowed_effects: ["PUBLIC_PUBLICATION"],
    forbidden_effects: [],
    resource_budgets: {},
    valid_from: "2026-09-24T00:00:00+04:00",
    expires_at: "2026-09-24T01:00:00+04:00",
    max_attempts: 1,
    max_parallelism: 1,
    revocation_epoch: 0,
    nonce: "nonce-12345678",
    policy_hash: "a".repeat(64),
    canon_hash: "b".repeat(64),
    human_consent_receipt_hash: "c".repeat(64),
    signature: "design-placeholder"
  };
  const result = validate("AuthorityLease", badLease);
  if (result.ok || !result.errors.some((x) => x.code === "HARD_EFFECT_CANNOT_BE_LEASE_AUTO_AUTHORIZED")) {
    throw new Error("self-test failed: hard re-consent effect was not rejected");
  }
  return { ok: true, tests: 1, truth_label: "REFERENCE_VALIDATOR_SELF_TEST_PASS" };
}

async function main(argv) {
  const [cmd, kind, file] = argv;
  if (cmd === "spec") {
    process.stdout.write(`${JSON.stringify(URP_SPEC, null, 2)}\n`);
    return;
  }
  if (cmd === "self-test") {
    process.stdout.write(`${JSON.stringify(selfTest(), null, 2)}\n`);
    return;
  }
  if (cmd === "validate") {
    if (!kind || !file) throw new Error("usage: validate <Kind> <json-file>");
    const obj = JSON.parse(await readFile(file, "utf8"));
    const result = validate(kind, obj);
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    if (!result.ok) process.exitCode = 2;
    return;
  }
  process.stderr.write("usage: node urp-contracts-v1.mjs spec | self-test | validate <Kind> <json-file>\n");
  process.exitCode = 64;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main(process.argv.slice(2)).catch((error) => {
    process.stderr.write(`${error.stack || error.message}\n`);
    process.exitCode = 1;
  });
}
