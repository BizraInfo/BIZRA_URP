# Deep Research Alignment — URP V3

**Purpose:** map external mature patterns to BIZRA design choices without importing external authority into BIZRA canon.

| External pattern | Relevant property | BIZRA adoption | BIZRA-specific constraint |
|---|---|---|---|
| SPIFFE trust domains / federation | independent identity namespaces, rotating trust bundles, explicit cross-domain trust | short-lived URP workload identities, separate trust roots, explicit bundle/key rotation | human/Node identity stays separate from workload identity; federation never creates human authority |
| RFC 8785 JCS | invariant JSON representation for hashing/signing | canonical JSON before BLAKE3/signature | reject ambiguous/non-canonical input; avoid hidden float semantics for economics |
| RFC 8949 deterministic CBOR | compact deterministic binary encoding | optional high-rate wire/storage encoding | schema/canon/policy versions remain explicit |
| RFC 9943 SCITT | signed statements, registration policy, verifiable data structures, receipts/inclusion proof, offline verification | receipt transparency service + epoch checkpoint proof | an inclusion receipt proves registration, not truth/impact; keep SAT attestation and PoI separate |
| OpenTelemetry | cross-component correlation using trace context | mission/lease/receipt/checkpoint correlation | telemetry is not authority and must exclude private payload by default |
| Kueue fair sharing/cohorts | historical usage fairness, shared quota, bounded borrowing/lending | resource cohorts, fair-share admission, quota lending/borrowing, backpressure | resources remain opt-in and sovereign; scheduler cannot infer contribution consent |

## Research-derived design deductions

### 1. Trust must be namespaced, not pooled

A trust-root bundle should remain bound to the identity namespace that issued it. URP must not merge unrelated trust anchors into a flat pool that could allow one authority domain to impersonate another.

### 2. Signing requires a single byte-level truth

Human-readable JSON is not enough for signatures. URP needs one canonical representation. For JSON-facing artifacts use JCS; for compact internal artifacts use deterministic CBOR if/when adopted.

### 3. Receipt registration is different from statement truth

The transparency layer can establish that a signed statement was accepted under a registration policy and included in a verifiable structure. It cannot prove the issuer was honest. BIZRA therefore needs four distinct questions:

1. Was the action/statement signed by the claimed issuer?
2. Was it registered/included under the stated policy?
3. Did independent SAT verification support it?
4. Did it create verified impact eligible for any economic effect?

Collapsing these four questions would create false GREEN.

### 4. Resource fairness needs memory

A scheduler that considers only current requests is easy to dominate. Historical share/borrowing should affect admission so continuously heavy consumers do not starve low-usage Nodes. Any preemption policy needs explicit stability rules to avoid oscillation.

### 5. Observability context belongs in evidence plumbing, not authority

Trace IDs make distributed diagnosis possible but cannot authorize effects. A trace is a correlation aid; a receipt is evidence; an authority lease is permission. V3 keeps these namespaces and powers separate.

## Direct implications for the 1M-node target

- Identity verification scales through hierarchical trust/caching, not one global session database.
- Receipt verification scales through append-only shard logs + batch checkpoints, not full global consensus per event.
- Resource allocation scales through regional cohorts/fair-share, not a single centralized queue.
- SAT scales through logical identities plus elastic workers, not millions of always-loaded models.
- Human sovereignty scales through bounded revocable authority leases, not per-microstep approval or unrestricted autonomy.
