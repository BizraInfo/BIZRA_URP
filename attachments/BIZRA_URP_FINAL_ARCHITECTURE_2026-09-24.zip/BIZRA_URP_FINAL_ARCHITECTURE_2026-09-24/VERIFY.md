# Bundle verification

Run from this directory:

```bash
sha256sum -c MANIFEST.sha256
node scripts/urp-contracts-v1.mjs self-test
node scripts/urp-contracts-v1.mjs spec | jq .
```

These checks verify bundle integrity/reference-script structure only. They do not prove a live URP runtime.
