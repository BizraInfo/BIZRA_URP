# URP Repo + Documentation Master Map

**Truth label:** PROPOSED TARGET TREE
**Mutation status:** no repo changes performed by this audit.

```text
Dema/
├── docs/
│   ├── canon/
│   │   ├── BIZRA_TOPOLOGY_CANON.md                  # existing authority
│   │   ├── BIZRA_URP_CONSTITUTION_v1.md             # NEW: shared-URP invariants only
│   │   ├── canon_registry.json                       # existing machine guard
│   │   └── schemas/
│   │       ├── topology.schema.json
│   │       ├── truth-label.schema.json
│   │       └── authority-effect.schema.json
│   ├── 02-architecture/
│   │   ├── URP_FINAL_ARCHITECTURE_V3.md             # NEW: master technical architecture
│   │   ├── URP_PHYSICAL_DEPLOYMENT_V1.md
│   │   ├── URP_CONSISTENCY_MODEL_V1.md
│   │   ├── URP_BLOCKTREE_BLOCKGRAPH_V1.md
│   │   ├── URP_SAT_RUNTIME_MODEL_V1.md
│   │   ├── URP_RESOURCE_SCHEDULER_V1.md
│   │   ├── URP_AUTHORITY_LEASES_V1.md
│   │   ├── URP_PRIVACY_MEMBRANE_V1.md
│   │   ├── URP_UKE_HOUSE_OF_WISDOM_V1.md
│   │   └── URP_POI_SHADOW_LEDGER_V1.md
│   ├── 04-protocols/
│   │   ├── URP_WIRE_PROTOCOL_V1.md
│   │   ├── URP_API_V1.md
│   │   ├── URP_EVENT_CATALOG_V1.md
│   │   ├── URP_CRYPTO_PROFILE_V1.md
│   │   └── URP_IDENTITY_PROFILE_V1.md
│   ├── 06-adr/
│   │   ├── ADR-URP-001-logical-singleton-physical-shards.md
│   │   ├── ADR-URP-002-sat-identities-vs-workers.md
│   │   ├── ADR-URP-003-authority-lease-consent.md
│   │   ├── ADR-URP-004-receipt-checkpointing.md
│   │   ├── ADR-URP-005-consistency-split.md
│   │   ├── ADR-URP-006-sat-role-canon.md
│   │   └── ADR-URP-007-canonical-serialization.md
│   ├── 07-security/
│   │   ├── URP_THREAT_MODEL_V1.md
│   │   ├── URP_ABUSE_CASES_V1.md
│   │   ├── URP_KEY_MANAGEMENT_V1.md
│   │   └── URP_PRIVACY_MODEL_V1.md
│   ├── 08-quality/
│   │   ├── URP_DOD_V1.md
│   │   ├── URP_TEST_MATRIX_V1.md
│   │   ├── URP_SLO_SLI_V1.md
│   │   └── URP_1M_VALIDATION_PLAN_V1.md
│   ├── 09-operations/
│   │   ├── URP_RUNBOOK_V1.md
│   │   ├── URP_INCIDENT_RESPONSE_V1.md
│   │   ├── URP_CAPACITY_PLAN_V1.md
│   │   └── URP_RECOVERY_REPLAY_V1.md
│   ├── receipts/
│   │   └── urp/                                      # receipts / proof pins only
│   └── archive/
│       └── superseded/
│           └── URP_ARCHITECTURE_v2.md                # move/copy only after explicit GO
├── packages/
│   ├── urp/
│   │   └── src/
│   │       ├── contracts/                             # pure schema/types first
│   │       ├── membrane/                              # FATE crossing + policy binding
│   │       ├── identity/                              # node/workload/pseudonym identities
│   │       ├── authority/                             # grants + leases + revocation
│   │       ├── scheduler/                             # admission/fair-share/backpressure
│   │       ├── resource/                              # offer/lease/settlement contracts
│   │       ├── sat/                                   # logical SAT registry + worker runtime
│   │       ├── receipts/                              # canonical signed statements
│   │       ├── blockgraph/                            # local lineage + typed cross-links
│   │       ├── checkpoint/                            # epoch Merkle roots / transparency
│   │       ├── knowledge/                             # UKE/House of Wisdom bridge
│   │       ├── poi/                                   # shadow-only until gates close
│   │       ├── telemetry/                             # OTel-safe correlation
│   │       └── adapters/                              # loopback/A2A/MCP/transport adapters
│   └── core/
│       └── src/
│           └── loop-emulator.js                       # existing; refactor config out of code
├── schemas/
│   └── urp/
│       ├── node-passport.v1.json
│       ├── authority-lease.v1.json
│       ├── mission-envelope.v1.json
│       ├── resource-offer.v1.json
│       ├── resource-lease.v1.json
│       ├── execution-receipt.v1.json
│       ├── verifier-attestation.v1.json
│       ├── wisdom-object.v1.json
│       ├── impact-record.v1.json
│       └── epoch-checkpoint.v1.json
├── scripts/
│   └── urp/
│       ├── conformance.mjs
│       ├── replay.mjs
│       ├── load-scenario.mjs
│       └── drift-check.mjs
└── tests/
    └── urp/
        ├── unit/
        ├── contract/
        ├── integration/
        ├── replay/
        ├── security/
        ├── chaos/
        ├── load/
        └── conformance/
```

## File ownership law

| Concern | Single source of truth | Derived artifacts may not override |
|---|---|---|
| Human/Node/PAT/SAT/URP topology | `docs/canon/BIZRA_TOPOLOGY_CANON.md` | diagrams, launch helpers, UI copy |
| Shared URP invariants | `docs/canon/BIZRA_URP_CONSTITUTION_v1.md` | implementation docs |
| Wire objects | `schemas/urp/*.json` + protocol version | ad-hoc JS objects |
| State transitions | architecture spec + state-machine tests | UI status strings |
| Consent/authority | ADR-005 + accepted Authority Lease ADR | agent self-authorization |
| Receipt format | crypto profile + receipt schema | storage implementation |
| SAT roster names | accepted SAT-role ADR + machine enum | historical prototypes |
| Runtime truth | measured receipts/tests/runtime probes | architecture prose |
| Public claim status | Claim Register / truth labels | marketing copy |

## Supersession rules

1. Do not delete historical documents; move them to `archive/superseded` only with explicit authority.
2. Add front matter: `status: SUPERSEDED`, `superseded_by`, `effective_date`, and immutable source hash.
3. A topology doc that conflicts with `BIZRA_TOPOLOGY_CANON.md` is non-authoritative even before archival.
4. Generated diagrams must be checked by `canon-check` against machine-readable topology invariants.
5. All numeric performance claims require a receipt or benchmark artifact naming hardware, commit, dataset/scenario, start/end times, and confidence/variance where applicable.
