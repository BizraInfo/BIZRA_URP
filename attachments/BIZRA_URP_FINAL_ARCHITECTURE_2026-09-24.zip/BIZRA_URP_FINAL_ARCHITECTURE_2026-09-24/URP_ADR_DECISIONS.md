# URP Architecture Decision Set

**Status:** PROPOSED — requires normal BIZRA authority/ADR process before becoming canon.

## ADR-URP-001 — One logical URP, many physical shards

**Decision:** Preserve one singular URP in the BIZRA semantic model while implementing it as a multi-region/multi-shard distributed system. No node is allowed to address another node directly. Nodes address the URP ingress/membrane; sharding is internal and hidden behind the logical URP identity.

**Why:** The current canon says one shared URP, while a literal single hub would create failure, latency, scaling, and sovereignty risks.

**Invariant:** `node -> membrane -> URP`, never `node -> node`.

## ADR-URP-002 — SAT identity is not SAT process residency

**Decision:** Each newly onboarded human contributes five canonical SAT logical identities/capacity entitlements to the shared URP, but the system does not keep five full model processes resident per node. SAT workers are activated elastically from bounded pools and execute under the logical identities, policy version, and receipt trail assigned to the work.

**Why:** At one million humans the canon implies five million SAT identities. Treating all five million as continuously resident LLM processes would be operationally wasteful and would confuse topology with scheduling.

## ADR-URP-003 — Scoped authority leases, never agent self-authorization

**Decision:** Introduce an `AuthorityLease` only as an operator-issued, time/resource/effect-bounded grant. A lease can authorize a finite class of already-understood reversible actions without asking the human for every micro-step. It is attenuable, revocable, expires automatically, and cannot widen itself.

**Hard boundary:** identity changes, canon changes, key operations, financial/economic effects, public publication, federation enrollment, destructive mutation, irreversible external effects, and any effect outside the lease require fresh explicit authority.

**Compatibility:** This does not weaken the founding law that capability may never self-authorize. It is a proposed scaling refinement to exact consent, not a bypass.

## ADR-URP-004 — Receipt stream locally/shard ordered; global checkpoint batched

**Decision:** Do not run global consensus for every mission step. Receipts are ordered in their local/shard stream, canonicalized, signed, and committed into Merkle accumulators. Epoch checkpoints commit shard roots, policy/canon hashes, revocation roots, and key-set identifiers. BlockTree expresses lineage; BlockGraph expresses typed cross-links such as verification, adoption, impact, dependency, and supersession.

**Why:** This keeps auditability while preventing the receipt layer from becoming a planetary serialization lock.

## ADR-URP-005 — Explicit consistency split

**Strongly consistent / serialized within authority domain:**
- node ordinal allocation,
- authority grant/lease creation + revocation,
- scarce resource lease allocation,
- key/revocation state,
- economic settlement/impact eligibility,
- epoch checkpoint publication.

**Eventually consistent / cacheable:**
- resource availability advertisements,
- telemetry,
- knowledge discovery indexes,
- skill metadata,
- non-authoritative dashboards,
- cached verification results.

## ADR-URP-006 — One canonical SAT roster

**Decision needed:** resolve all conflicting SAT names into one versioned enum and migrate every prototype, UI, test, receipt, and doc.

**Current repo canon at audit time:**
- S1 Validator
- S2 Oracle (FROZEN)
- S3 Mediator
- S4 Archivist
- S5 Sentinel

**Known conflicting prototype:** `packages/urp/src/five-sat-urp-launch.js` names Guardian, Reasoner, Builder, Critic, Archivist. The prototype must not silently redefine topology.

## ADR-URP-007 — Canonical serialization and crypto agility

**Decision:**
- JSON-facing APIs use RFC 8785 JCS before content hashing/signing.
- Compact internal wire/storage may use deterministic CBOR per RFC 8949.
- Every signed object carries `schema`, `schema_version`, `canon_version`, `hash_alg`, `sig_alg`, `key_id`, and `policy_hash`.
- BLAKE3 remains BIZRA's content/receipt hash where canon requires it.
- Ed25519 remains the initial signing profile where already bound, but algorithm identifiers are explicit so future migration is possible.
- Economic values use exact integer/fixed-point domain types, never unconstrained binary floating point.

## ADR-URP-008 — Workload identity distinct from human/node identity

**Decision:** Use short-lived workload identities (SPIFFE/SPIRE-style trust-domain semantics) for URP services and SAT workers. Human identity, Node pseudonym, device identity, workload identity, and signing-key identity are different namespaces and MUST NOT be collapsed.

## ADR-URP-009 — PoI starts in shadow mode

**Decision:** Resource use and impact calculations may be measured and receipted before they can affect SEED/BLOOM or reward eligibility. Shadow ledgers must expose counterfactual outcomes without settlement power.

## ADR-URP-010 — Observability is evidence support, not authority

**Decision:** OpenTelemetry-style TraceId/SpanId correlation joins mission, authority lease, resource lease, receipt, verifier attestation, and checkpoint events. Telemetry may diagnose; it may not grant authority or substitute for receipts.
